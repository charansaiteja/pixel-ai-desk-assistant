# Learning Log

Concepts I learned while building Pixel and the earlier ESP32 projects, written as notes for review and interview prep.

## 1. ESP32 and embedded hardware

- **ESP32**: a low-cost microcontroller with Wi-Fi and Bluetooth, dual-core, 240 MHz. My board is an ESP32-32E with a 2.8" ILI9341 screen (320×240).
- **Compile vs. upload**: compiling builds the program; uploading (flashing) writes it to the chip. Holding **BOOT** forces flashing mode if an upload gets stuck.
- **setup() and loop()**: `setup()` runs once at power-on; `loop()` runs forever.
- **GPIO pins** connect the chip to the outside world, and every board wires them differently. On my board, pin 2 is used by the display, which is why a "built-in LED" test didn't work.
- **SPI**: the fast bus the ESP32 uses to talk to the display.
- **Libraries** (Adafruit ILI9341 / GFX) handle low-level display control so I can draw shapes and text.
- **RGB565**: 16-bit color (5 bits red, 6 green, 5 blue). Green gets the extra bit because human eyes are most sensitive to it.
- **millis() vs. delay()**: timing with `millis()` lets the ESP32 animate and listen for commands at the same time.
- **State machine**: a variable like `mode` or `emotion` decides how the device behaves right now.
- **C++ rule**: functions can't be defined inside other functions; every `{` needs a matching `}`.

## 2. PC ↔ ESP32 communication

- **Serial / UART** over USB at a fixed **baud rate** (115200). Both sides must match.
- **One program per port**: a COM port can only be opened by one program at a time (Arduino IDE vs. Python conflicts).
- **DTR/RTS**: opening a port can reset the ESP32; setting both to `False` in pySerial prevents it.
- **Protocol design**: each message ends with `\n` (**framing**) and starts with a type prefix (`EMO:`, `TXT:`).
- **Two-way communication**: the ESP32 can reply, which confirms messages actually arrived.
- **Debouncing**: only acting after a value is stable for several frames removes flicker from noisy signals.

## 3. Computer vision

- **OpenCV** captures webcam frames and draws overlays.
- **MediaPipe Hands** is a trained neural network that finds 21 landmarks on a hand per frame. Running a trained model on new data is **inference**.
- **AI output → logic**: simple geometry on landmarks (fingertip above knuckle = finger up) turns model output into decisions.
- **System design**: heavy AI on the PC, display and control on the ESP32, each device doing what it's good at.

## 4. Python environment

- **Version compatibility**: some libraries don't support the newest Python (MediaPipe needed 3.11, not 3.14).
- **Pinning versions** (`mediapipe==0.10.14`, `numpy<2`) prevents breaking changes.
- **Virtual environment (`.venv`)**: a private Python per project so dependencies don't conflict.
- **requirements.txt**: the list of dependencies; `pip install -r requirements.txt` recreates the setup.
- **VS Code**: open a folder as a project, select the interpreter, use the integrated terminal, read the Problems panel.

## 5. Local LLMs with Ollama

- **Ollama** runs models locally as a server at `localhost:11434`. Any language can call it over HTTP.
- **Local vs. cloud**: local = private, free, offline; but smaller models and limited by hardware.
- **Parameters**: model size (3B = 3 billion). Bigger is usually smarter, slower, and needs more memory.
- **Quantization**: storing weights in ~4 bits instead of 16, trading a little accuracy for much less memory.
- **VRAM and KV cache**: a 2 GB model used 3.1 GB because of the KV cache (conversation working memory, grows with context length) and compute buffers. On a 4 GB GPU it split 73% CPU / 27% GPU, which is slower. `ollama ps` shows the split.
- **Message roles**: `system` (rules/personality), `user`, `assistant`.
- **LLMs are stateless**: the model remembers nothing between calls. Memory exists only because the app resends the full history each time.
- **Temperature**: low = consistent, high = creative. Use low values when controlling hardware.

## 6. Structured output

- **Problem**: free text can't be reliably used by code.
- **Solution**: give the model a **JSON schema**; Ollama applies **constrained decoding** so output always matches it.
- **Pydantic** defines the schema (`PixelReply`) and validates the result. `Literal[...]` restricts emotions to valid values.
- **Fallback**: a `try/except` shows a neutral face if validation fails, instead of crashing.
- **UX for latency**: showing "thinking" eyes while waiting makes delays feel intentional.

## 7. Engineering habits

- **Debug one layer at a time**: camera → detection → message sent → ESP32 reply.
- **Read error messages**: "Access is denied" = busy port; "No matching distribution" = wrong Python version; "No such file" = file doesn't exist yet.
- **Measure before optimizing**: use `ollama run --verbose` (tokens/s) before and after changes.
- **Git & GitHub**: README, `.gitignore`, license (MIT), clean project structure.

## Interview questions I can answer

- Why run an LLM locally instead of using an API?
- What is quantization, and what's the trade-off?
- Why does a 2 GB model need more than 2 GB of memory?
- How does a chatbot remember a conversation?
- How do you get reliable structured data from an LLM?
- How do the PC and microcontroller communicate, and how does the receiver know where a message ends?
- Why use a virtual environment?
