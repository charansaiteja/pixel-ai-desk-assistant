// Pixel Face - emotion display for the Pixel AI desk assistant
// Board: ESP32-32E 2.8" TFT (ILI9341, 320x240)
//
// Protocol (USB serial, 115200 baud, one command per line):
//   EMO:<emotion>   -> happy | sad | angry | surprised | thinking | neutral
//   TXT:<text>      -> reply text shown under the eyes

#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ILI9341.h>

#define TFT_CS 15
#define TFT_DC 2
#define TFT_BL 21
Adafruit_ILI9341 tft(&SPI, TFT_DC, TFT_CS, -1);

String emotion = "neutral";
unsigned long lastBlink = 0;

// Eye color changes with Pixel's mood (RGB565 via color565)
uint16_t eyeColor() {
  if (emotion == "happy")     return tft.color565(255, 210, 0);    // warm yellow
  if (emotion == "sad")       return tft.color565(60, 120, 255);   // blue
  if (emotion == "angry")     return tft.color565(255, 40, 40);    // red
  if (emotion == "surprised") return tft.color565(255, 120, 200);  // pink
  if (emotion == "thinking")  return tft.color565(170, 90, 255);   // purple
  return tft.color565(0, 230, 255);                                // neutral: cyan
}

const uint16_t BG = ILI9341_BLACK;

void drawEyes(bool closed) {
  tft.fillRect(0, 0, 320, 140, BG);
  uint16_t EYE = eyeColor();
  int xs[2] = {70, 180};                 // left edge of each eye

  for (int i = 0; i < 2; i++) {
    int x = xs[i];
    if (closed) { tft.fillRoundRect(x, 70, 70, 10, 5, EYE); continue; }

    if (emotion == "happy") {
      tft.fillRoundRect(x, 30, 70, 80, 25, EYE);
      tft.fillCircle(x + 35, 125, 45, BG);             // carve bottom = smiling eyes
    } else if (emotion == "sad") {
      tft.fillRoundRect(x, 40, 70, 80, 20, EYE);
      if (i == 0) tft.fillTriangle(x, 40, x + 70, 40, x, 75, BG);       // outer corners droop
      else        tft.fillTriangle(x, 40, x + 70, 40, x + 70, 75, BG);
    } else if (emotion == "angry") {
      tft.fillRoundRect(x, 40, 70, 80, 20, EYE);
      if (i == 0) tft.fillTriangle(x, 40, x + 70, 40, x + 70, 75, BG);  // inner corners slant down
      else        tft.fillTriangle(x, 40, x + 70, 40, x, 75, BG);
    } else if (emotion == "surprised") {
      tft.fillCircle(x + 35, 75, 45, EYE);
      tft.fillCircle(x + 35, 75, 15, BG);
    } else if (emotion == "thinking") {
      tft.fillRoundRect(x + 10, 30, 60, 50, 15, EYE);  // eyes look up
    } else {                                            // neutral
      tft.fillRoundRect(x, 30, 70, 90, 20, EYE);
    }
  }
}

void showText(String t) {
  tft.fillRect(0, 140, 320, 100, BG);
  tft.drawFastHLine(10, 142, 300, ILI9341_DARKGREY);
  tft.setTextColor(eyeColor());          // text matches Pixel's mood
  tft.setTextSize(2);
  tft.setTextWrap(true);
  tft.setCursor(8, 152);
  tft.print(t);
}

void setup() {
  Serial.begin(115200);
  Serial.setTimeout(100);
  pinMode(TFT_BL, OUTPUT);
  digitalWrite(TFT_BL, HIGH);            // backlight on
  SPI.begin(14, 12, 13, TFT_CS);         // SCK, MISO, MOSI, CS
  tft.begin(40000000);
  tft.setRotation(1);                    // landscape
  tft.fillScreen(BG);
  drawEyes(false);
  showText("Hi! I'm Pixel.");
}

void loop() {
  if (Serial.available()) {
    String line = Serial.readStringUntil('\n');
    line.trim();
    if (line.startsWith("EMO:")) {
      emotion = line.substring(4);
      drawEyes(false);
    } else if (line.startsWith("TXT:")) {
      showText(line.substring(4));
    }
  }

  if (millis() - lastBlink > 4000) {     // blink every 4 seconds
    lastBlink = millis();
    drawEyes(true);
    delay(120);
    drawEyes(false);
  }
}
