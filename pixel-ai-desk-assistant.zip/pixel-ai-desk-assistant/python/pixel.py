"""Pixel - a local AI desk assistant.

Chats with a local LLM through Ollama, gets a structured reply
(emotion + text), and shows it on the ESP32 screen over USB serial.
Pair with: esp32/pixel_face/pixel_face.ino
"""
import os
import time
from typing import Literal

import ollama
import serial
from pydantic import BaseModel, ValidationError

# Settings (override with environment variables if needed)
MODEL = os.getenv("PIXEL_MODEL", "llama3.2:3b")
PORT = os.getenv("PIXEL_PORT", "COM7")


class PixelReply(BaseModel):
    """The exact shape we want the LLM's answer to have."""
    emotion: Literal["happy", "sad", "angry", "surprised", "thinking", "neutral"]
    reply: str


SYSTEM = """You are Pixel, a small desk robot with a face on a screen.
Reply in 1-2 short sentences, under 120 characters.
Pick the emotion that matches how Pixel feels about the message."""


def open_esp32(port: str) -> serial.Serial:
    esp = serial.Serial()
    esp.port = port
    esp.baudrate = 115200
    esp.dtr = False   # don't reset the ESP32 when opening the port
    esp.rts = False
    esp.open()
    time.sleep(2)
    return esp


def clean(text: str) -> str:
    """The ESP32 font only supports basic characters, so remove emojis etc."""
    return text.encode("ascii", "ignore").decode()[:130]


def main():
    esp = open_esp32(PORT)

    def send(line: str):
        """Send one command to the ESP32. Each command ends with a newline."""
        esp.write((line + "\n").encode())

    messages = [{"role": "system", "content": SYSTEM}]
    print(f"Pixel is ready (model: {MODEL}, port: {PORT}). Type 'quit' to exit.")

    try:
        while True:
            user = input("You: ").strip()
            if not user:
                continue
            if user.lower() in ("quit", "exit"):
                break

            send("EMO:thinking")   # visual feedback while the LLM works
            messages.append({"role": "user", "content": user})

            response = ollama.chat(
                model=MODEL,
                messages=messages,
                format=PixelReply.model_json_schema(),  # constrained JSON output
                options={"temperature": 0.3},
            )
            raw = response["message"]["content"]

            try:
                data = PixelReply.model_validate_json(raw)
            except ValidationError:
                data = PixelReply(emotion="neutral", reply="Sorry, I got confused.")

            messages.append({"role": "assistant", "content": raw})

            send("EMO:" + data.emotion)
            send("TXT:" + clean(data.reply))
            print(f"Pixel [{data.emotion}]: {data.reply}")
    finally:
        esp.close()


if __name__ == "__main__":
    main()
