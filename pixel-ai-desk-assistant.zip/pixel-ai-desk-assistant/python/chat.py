"""Phase 1: a minimal terminal chat with a local LLM through Ollama.
No hardware needed. Shows system prompts, message roles, and how
conversation memory works (the full history is resent every turn).
"""
import os

import ollama

MODEL = os.getenv("PIXEL_MODEL", "llama3.2:3b")

messages = [
    {"role": "system", "content": "You are Pixel, a friendly desk robot assistant. Keep answers short, 1-2 sentences."}
]

while True:
    user = input("You: ")
    if user.lower() in ("quit", "exit"):
        break

    messages.append({"role": "user", "content": user})
    response = ollama.chat(model=MODEL, messages=messages, options={"temperature": 0.7})
    reply = response["message"]["content"]
    messages.append({"role": "assistant", "content": reply})

    print("Pixel:", reply)
